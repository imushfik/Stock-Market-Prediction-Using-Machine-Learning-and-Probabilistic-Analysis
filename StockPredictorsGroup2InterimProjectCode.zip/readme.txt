MIT651 Interim Project Code Submission
Team: StockPredictors Group 2
Members: Mushfikul Islam; Sayed md asif same; Chandra Laxmi
Project: Stock Market Prediction Using Machine Learning and Probabilistic Analysis
Scope: Sprint 1 and Sprint 2

GitHub repository:
https://github.com/imushfik/Stock-Market-Prediction-Using-Machine-Learning-and-Probabilistic-Analysis

GITHUB SUBMISSION STATUS: NOT YET VERIFIED.
After pushing StockPredictorsGroup2InterimProjectCode.zip to the team's GitHub Classroom repository before the deadline, replace this status with a truthful confirmation that the final submission was uploaded on time. Verify the GitHub commit history and add the commit URL and date/time below. Do not claim timely submission until verified.

Commit URL: [add after push]
Commit date/time: [add after push]

LMS submission: Upload the ZIP containing this readme.txt as instructed by SIHE LMS.
