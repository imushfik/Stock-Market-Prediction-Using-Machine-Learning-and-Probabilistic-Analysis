"""
Manual test script for Sprint 1 (SMP-1, SMP-2, SMP-3).
Run the API first (uvicorn main:app --reload), then run this script:
    python test_sprint1.py

It prints PASS/FAIL for each scenario so you can confirm the demo will work
before presenting it live.
"""

import requests

BASE_URL = "http://127.0.0.1:8000"


def check(label, condition):
    print(f"[{'PASS' if condition else 'FAIL'}] {label}")


def test_happy_path():
    print("\n--- Happy path: valid symbol (AAPL) ---")

    # SMP-1: select stock
    r = requests.post(f"{BASE_URL}/api/stock/select", json={
        "symbol": "AAPL",
        "start_date": "2024-01-01",
        "end_date": "2024-06-01",
    })
    check("SMP-1 select_stock returns 200", r.status_code == 200)

    # SMP-2: retrieve historical data
    r = requests.get(f"{BASE_URL}/api/stock/historical", params={
        "symbol": "AAPL",
        "start_date": "2024-01-01",
        "end_date": "2024-06-01",
    })
    check("SMP-2 historical data returns 200", r.status_code == 200)
    if r.status_code == 200:
        check("SMP-2 returns non-empty data", r.json()["row_count"] > 0)

    # SMP-3: validate data
    r = requests.get(f"{BASE_URL}/api/stock/validate", params={
        "symbol": "AAPL",
        "start_date": "2024-01-01",
        "end_date": "2024-06-01",
    })
    check("SMP-3 validate returns 200", r.status_code == 200)
    if r.status_code == 200:
        check("SMP-3 marks valid AAPL data as valid", r.json()["valid"] is True)


def test_failure_path():
    print("\n--- Failure path: invalid symbol (ZZZZZZZ) ---")

    r = requests.get(f"{BASE_URL}/api/stock/historical", params={
        "symbol": "ZZZZZZZ",
        "start_date": "2024-01-01",
        "end_date": "2024-06-01",
    })
    check("SMP-2 invalid symbol returns 404", r.status_code == 404)

    r = requests.get(f"{BASE_URL}/api/stock/validate", params={
        "symbol": "ZZZZZZZ",
        "start_date": "2024-01-01",
        "end_date": "2024-06-01",
    })
    check("SMP-3 invalid symbol returns 200 with valid=False", r.status_code == 200 and r.json()["valid"] is False)

    print("\n--- Failure path: insufficient history (2-day range) ---")
    r = requests.get(f"{BASE_URL}/api/stock/validate", params={
        "symbol": "AAPL",
        "start_date": "2024-01-01",
        "end_date": "2024-01-03",
    })
    if r.status_code == 200:
        check("SMP-3 flags insufficient history", r.json()["valid"] is False)


if __name__ == "__main__":
    test_happy_path()
    test_failure_path()
