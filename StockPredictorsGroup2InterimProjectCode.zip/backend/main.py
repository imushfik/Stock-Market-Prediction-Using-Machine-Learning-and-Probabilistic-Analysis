"""
Sprint 1 backend: Market Selection and Data Validation
Covers:
  SMP-1: Select a target stock
  SMP-2: Retrieve historical market data
  SMP-3: Validate the collected data
"""

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from datetime import datetime
import yfinance as yf
import pandas as pd

app = FastAPI(title="Stock Prediction - Sprint 1 API")

# Allow the React frontend (running on localhost:3000 or 5173) to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

MIN_REQUIRED_ROWS = 30  # minimum history required for later ML steps


class StockSelection(BaseModel):
    symbol: str
    start_date: str  # format YYYY-MM-DD
    end_date: str


# ---------- SMP-1: Select a target stock ----------
@app.post("/api/stock/select")
def select_stock(selection: StockSelection):
    """
    Accepts the user's chosen symbol and date range.
    Basic input validation happens here before we ever touch the data source.
    """
    symbol = selection.symbol.strip().upper()

    if not symbol:
        raise HTTPException(status_code=400, detail="Stock symbol cannot be empty.")

    try:
        start = datetime.strptime(selection.start_date, "%Y-%m-%d")
        end = datetime.strptime(selection.end_date, "%Y-%m-%d")
    except ValueError:
        raise HTTPException(status_code=400, detail="Dates must be in YYYY-MM-DD format.")

    if start >= end:
        raise HTTPException(status_code=400, detail="Start date must be before end date.")

    return {
        "status": "accepted",
        "symbol": symbol,
        "start_date": selection.start_date,
        "end_date": selection.end_date,
    }


# ---------- SMP-2: Retrieve historical market data ----------
def fetch_historical_data(symbol: str, start_date: str, end_date: str) -> pd.DataFrame:
    """
    Pulls OHLCV data from Yahoo Finance via yfinance.
    Returns an empty DataFrame if the symbol is invalid or has no data.
    """
    ticker = yf.Ticker(symbol)
    df = ticker.history(start=start_date, end=end_date)
    return df


@app.get("/api/stock/historical")
def get_historical_data(
    symbol: str = Query(...),
    start_date: str = Query(...),
    end_date: str = Query(...),
):
    symbol = symbol.strip().upper()
    df = fetch_historical_data(symbol, start_date, end_date)

    if df.empty:
        raise HTTPException(
            status_code=404,
            detail=f"No historical data found for symbol '{symbol}'. "
                   f"Check the symbol and date range and try again.",
        )

    # Return as a list of records the frontend can render in a table/chart
    df = df.reset_index()
    df["Date"] = df["Date"].astype(str)
    records = df[["Date", "Open", "High", "Low", "Close", "Volume"]].to_dict(orient="records")

    return {"symbol": symbol, "row_count": len(records), "data": records}


# ---------- SMP-3: Validate the collected data ----------
@app.get("/api/stock/validate")
def validate_stock_data(
    symbol: str = Query(...),
    start_date: str = Query(...),
    end_date: str = Query(...),
):
    """
    Runs the validation checks described in the proposal:
    - symbol availability
    - chronological order
    - missing values
    - minimum history requirement
    """
    symbol = symbol.strip().upper()
    df = fetch_historical_data(symbol, start_date, end_date)

    issues = []

    # Check 1: symbol availability / data returned at all
    if df.empty:
        issues.append(f"Symbol '{symbol}' returned no data. It may be invalid or delisted.")
        return {"symbol": symbol, "valid": False, "issues": issues, "row_count": 0}

    # Check 2: minimum history requirement
    if len(df) < MIN_REQUIRED_ROWS:
        issues.append(
            f"Only {len(df)} rows retrieved; at least {MIN_REQUIRED_ROWS} are required "
            f"for reliable feature engineering."
        )

    # Check 3: missing values
    missing_count = int(df[["Open", "High", "Low", "Close", "Volume"]].isnull().sum().sum())
    if missing_count > 0:
        issues.append(f"Dataset contains {missing_count} missing values across OHLCV fields.")

    # Check 4: chronological order
    if not df.index.is_monotonic_increasing:
        issues.append("Data is not in chronological order.")

    is_valid = len(issues) == 0

    return {
        "symbol": symbol,
        "valid": is_valid,
        "issues": issues,
        "row_count": len(df),
    }


@app.get("/")
def root():
    return {"message": "Sprint 1 API is running. See /docs for interactive testing."}


# Sprint 1 HTML Demo Interface
from fastapi.responses import HTMLResponse

@app.get("/demo", response_class=HTMLResponse)
def demo_interface():
    with open("test_smp1.html", "r", encoding="utf-8") as f:
        return f.read()




# ===== SPRINT 2 ML PREDICTION =====

import joblib
import numpy as np

from pathlib import Path
from datetime import timezone, timedelta
from functools import lru_cache


class StockPredictionRequest(BaseModel):
    symbol: str


@lru_cache(maxsize=1)
def load_prediction_bundle():
    model_path = (
        Path(__file__).resolve().parent
        / "sprint2_stock_model.joblib"
    )

    if not model_path.exists():
        raise HTTPException(
            status_code=503,
            detail="Machine learning model not found."
        )

    return joblib.load(model_path)


def prepare_prediction_features(df):

    data = df.copy()

    required_cols = [
        "Open", "High", "Low", "Close", "Volume"
    ]

    # Sort historical data
    data = data.sort_index()

    # Convert values to numeric
    for col in required_cols:
        data[col] = pd.to_numeric(
            data[col], errors="coerce"
        )

    # Clean historical records
    data = data.dropna(subset=required_cols)

    valid_prices = (
        data[["Open", "High", "Low", "Close"]] > 0
    ).all(axis=1)

    data = data.loc[
        valid_prices & (data["Volume"] >= 0)
    ].copy()

    if len(data) < 30:
        raise HTTPException(
            status_code=422,
            detail="Insufficient historical stock data."
        )

    # Recreate Sprint 2 training features
    data["Return_1d"] = data["Close"].pct_change()

    data["Return_5d"] = data["Close"].pct_change(5)

    data["MA_5"] = (
        data["Close"].rolling(5).mean()
    )

    data["MA_10"] = (
        data["Close"].rolling(10).mean()
    )

    data["MA_20"] = (
        data["Close"].rolling(20).mean()
    )

    data["Volatility_10"] = (
        data["Return_1d"].rolling(10).std()
    )

    data["Volume_MA_10"] = (
        data["Volume"].rolling(10).mean()
    )

    data["Volume_Ratio"] = (
        data["Volume"] /
        data["Volume_MA_10"].replace(0, np.nan)
    )

    data["Price_vs_MA20"] = (
        data["Close"] / data["MA_20"] - 1
    )

    data["Daily_Range"] = (
        (data["High"] - data["Low"]) /
        data["Close"]
    )

    bundle = load_prediction_bundle()
    features = bundle["features"]

    latest = data[features].tail(1)

    latest = latest.replace(
        [np.inf, -np.inf], np.nan
    )

    if latest.isna().any().any():
        raise HTTPException(
            status_code=422,
            detail="Latest stock features contain invalid values."
        )

    return latest, data


@app.post("/api/stock/predict")
def predict_stock(request: StockPredictionRequest):

    symbol = request.symbol.strip().upper()

    if not symbol:
        raise HTTPException(
            status_code=400,
            detail="Stock symbol cannot be empty."
        )

    # Load saved Sprint 2 model
    bundle = load_prediction_bundle()

    # Model currently supports AAPL only
    if symbol != bundle["symbol"]:
        raise HTTPException(
            status_code=400,
            detail=(
                "This model currently supports "
                f"{bundle['symbol']} only."
            )
        )

    # Retrieve approximately 120 days of data
    # End date is exclusive, avoiding the
    # current potentially incomplete trading day.
    end_date = datetime.now(timezone.utc).date()

    start_date = end_date - timedelta(days=120)

    try:
        historical = fetch_historical_data(
            symbol,
            str(start_date),
            str(end_date)
        )
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail="Market data retrieval failed."
        ) from exc

    if historical.empty:
        raise HTTPException(
            status_code=404,
            detail="No historical stock data available."
        )

    # Calculate technical indicators
    features, cleaned_data = (
        prepare_prediction_features(historical)
    )

    # Predict using saved model
    model = bundle["model"]

    prediction = int(model.predict(features)[0])

    probabilities = model.predict_proba(features)[0]

    classes = list(model.classes_)

    probability_up = float(
        probabilities[classes.index(1)]
    )

    direction = (
        "UP" if prediction == 1
        else "DOWN / NOT UP"
    )

    # Return prediction results
    return {
        "symbol": symbol,
        "model": bundle["model_name"],
        "prediction": prediction,
        "direction": direction,
        "probability_up": round(probability_up, 4),
        "probability_down": round(
            1 - probability_up, 4
        ),
        "last_data_date": str(
            cleaned_data.index[-1].date()
        ),
        "historical_rows": len(cleaned_data),
        "status": "success",
        "disclaimer": (
            "Experimental machine learning prediction. "
            "Not financial advice."
        )
    }


# ===== SPRINT 2 HTML DEMO =====
from fastapi.responses import FileResponse

@app.get("/demo-sprint2")
def sprint2_demo():
    html_file = (
        Path(__file__).resolve().parent
        / "test_sprint2.html"
    )
    return FileResponse(
        html_file,
        media_type="text/html"
    )
