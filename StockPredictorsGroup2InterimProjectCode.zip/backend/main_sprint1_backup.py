"""
Sprint 1 backend: Market Selection and Data Validation
Covers:
  SMP-1: Select a target stock
  SMP-2: Retrieve historical market data
  SMP-3: Validate the collected data
"""

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from datetime import datetime
import yfinance as yf
import pandas as pd

app = FastAPI(title="Stock Prediction - Sprint 1 API")

# Allow the React frontend (running on localhost:3000 or 5173) to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

MIN_REQUIRED_ROWS = 30  # minimum history required for later ML steps


class StockSelection(BaseModel):
    symbol: str
    start_date: str  # format YYYY-MM-DD
    end_date: str


# ---------- SMP-1: Select a target stock ----------
@app.post("/api/stock/select")
def select_stock(selection: StockSelection):
    """
    Accepts the user's chosen symbol and date range.
    Basic input validation happens here before we ever touch the data source.
    """
    symbol = selection.symbol.strip().upper()

    if not symbol:
        raise HTTPException(status_code=400, detail="Stock symbol cannot be empty.")

    try:
        start = datetime.strptime(selection.start_date, "%Y-%m-%d")
        end = datetime.strptime(selection.end_date, "%Y-%m-%d")
    except ValueError:
        raise HTTPException(status_code=400, detail="Dates must be in YYYY-MM-DD format.")

    if start >= end:
        raise HTTPException(status_code=400, detail="Start date must be before end date.")

    return {
        "status": "accepted",
        "symbol": symbol,
        "start_date": selection.start_date,
        "end_date": selection.end_date,
    }


# ---------- SMP-2: Retrieve historical market data ----------
def fetch_historical_data(symbol: str, start_date: str, end_date: str) -> pd.DataFrame:
    """
    Pulls OHLCV data from Yahoo Finance via yfinance.
    Returns an empty DataFrame if the symbol is invalid or has no data.
    """
    ticker = yf.Ticker(symbol)
    df = ticker.history(start=start_date, end=end_date)
    return df


@app.get("/api/stock/historical")
def get_historical_data(
    symbol: str = Query(...),
    start_date: str = Query(...),
    end_date: str = Query(...),
):
    symbol = symbol.strip().upper()
    df = fetch_historical_data(symbol, start_date, end_date)

    if df.empty:
        raise HTTPException(
            status_code=404,
            detail=f"No historical data found for symbol '{symbol}'. "
                   f"Check the symbol and date range and try again.",
        )

    # Return as a list of records the frontend can render in a table/chart
    df = df.reset_index()
    df["Date"] = df["Date"].astype(str)
    records = df[["Date", "Open", "High", "Low", "Close", "Volume"]].to_dict(orient="records")

    return {"symbol": symbol, "row_count": len(records), "data": records}


# ---------- SMP-3: Validate the collected data ----------
@app.get("/api/stock/validate")
def validate_stock_data(
    symbol: str = Query(...),
    start_date: str = Query(...),
    end_date: str = Query(...),
):
    """
    Runs the validation checks described in the proposal:
    - symbol availability
    - chronological order
    - missing values
    - minimum history requirement
    """
    symbol = symbol.strip().upper()
    df = fetch_historical_data(symbol, start_date, end_date)

    issues = []

    # Check 1: symbol availability / data returned at all
    if df.empty:
        issues.append(f"Symbol '{symbol}' returned no data. It may be invalid or delisted.")
        return {"symbol": symbol, "valid": False, "issues": issues, "row_count": 0}

    # Check 2: minimum history requirement
    if len(df) < MIN_REQUIRED_ROWS:
        issues.append(
            f"Only {len(df)} rows retrieved; at least {MIN_REQUIRED_ROWS} are required "
            f"for reliable feature engineering."
        )

    # Check 3: missing values
    missing_count = int(df[["Open", "High", "Low", "Close", "Volume"]].isnull().sum().sum())
    if missing_count > 0:
        issues.append(f"Dataset contains {missing_count} missing values across OHLCV fields.")

    # Check 4: chronological order
    if not df.index.is_monotonic_increasing:
        issues.append("Data is not in chronological order.")

    is_valid = len(issues) == 0

    return {
        "symbol": symbol,
        "valid": is_valid,
        "issues": issues,
        "row_count": len(df),
    }


@app.get("/")
def root():
    return {"message": "Sprint 1 API is running. See /docs for interactive testing."}


# Sprint 1 HTML Demo Interface
from fastapi.responses import HTMLResponse

@app.get("/demo", response_class=HTMLResponse)
def demo_interface():
    with open("test_smp1.html", "r", encoding="utf-8") as f:
        return f.read()
