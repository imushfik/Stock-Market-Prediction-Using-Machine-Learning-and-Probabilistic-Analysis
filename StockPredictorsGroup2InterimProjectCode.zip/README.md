# StockPredictors — Group 2 Interim Project Code

## Team
- Mushfikul Islam
- Sayed md asif same
- Chandra Laxmi

## Scope
Sprint 1 and Sprint 2 of the Stock Prediction project.

## Files
- `backend/main.py`: FastAPI backend (current version)
- `backend/main_sprint1_backup.py`: original Sprint 1 backend backup
- `backend/requirements.txt`: backend Python dependencies
- `backend/test_sprint1.py`: Sprint 1 automated tests
- `backend/test_smp1.html`: Sprint 1 browser demo
- `backend/test_sprint2.html`: Sprint 2 browser demo
- `backend/sprint2_stock_model.joblib`: saved Sprint 2 model artifact
- `notebooks/Group2_Sprint1_Sprint2_Colab.ipynb`: submitted Google Colab notebook, including code and saved outputs

## Run
Install backend dependencies with `pip install -r requirements.txt` and run the API from the backend directory with `uvicorn main:app --host 0.0.0.0 --port 8000`.

Note: The Colab notebook may contain environment-specific paths and setup steps. The model artifact may need the matching training libraries to load. No execution or grading verification is claimed by this package.
